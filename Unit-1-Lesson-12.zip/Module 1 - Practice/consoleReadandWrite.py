print("You will be asked to enter your name \nThis will happen in the next line.")
userName = input("What is your name? ")
print("Hello,", userName)