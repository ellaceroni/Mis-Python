fileObject = open("test.txt", "w")
fileObject.write("This line will be saved to the test.txt file.")
fileObject.close()