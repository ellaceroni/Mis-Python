firstName = input("What is your first name? ")
lastName = input("What is your last name? ")
domainName = input("What domain name would you like to use? ")
email = lastName + "." + firstName + "@" + domainName

print("Hello " + firstName +",\n" + "Your new email address is:  " + email)