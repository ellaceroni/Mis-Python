def check(input):
  return isinstance(input, int) and int(input) % 2 == 0

print(check(4))
    